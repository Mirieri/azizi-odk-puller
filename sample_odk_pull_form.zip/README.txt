README
======

Upload sample_pull_form.xls in Azizi's Biorepository site (and not directly into ODK Aggregate) with cows.sql and itemsets.sql as the media files
