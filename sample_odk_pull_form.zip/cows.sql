select cow_id, cow_name from cows;
